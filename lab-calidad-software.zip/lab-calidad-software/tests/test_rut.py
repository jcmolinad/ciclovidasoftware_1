"""Pruebas unitarias de validar_rut().

MISIÓN 1: ejecuta
    python -m pytest tests/test_rut.py -v
Algunas pruebas fallan. Lee los mensajes de error: ¿qué tienen en común
los RUT que fallan? Encuentra el defecto en tienda/validaciones.py,
corrígelo y vuelve a ejecutar hasta ver todo en verde.
IMPORTANTE: corrige el código, NO las pruebas.
"""
from tienda.validaciones import validar_rut


# ---------- RUT que deben ser aceptados ----------

def test_rut_con_puntos_y_guion_es_valido():
    assert validar_rut("12.345.678-5") is True


def test_rut_sin_puntos_es_valido():
    assert validar_rut("12345678-5") is True


def test_rut_de_siete_digitos_es_valido():
    assert validar_rut("7.654.321-6") is True


def test_rut_con_digito_k_es_valido():
    assert validar_rut("10.000.013-K") is True


def test_rut_con_k_minuscula_es_valido():
    assert validar_rut("10000013-k") is True


def test_rut_con_digito_cero_es_valido():
    assert validar_rut("14.000.000-0") is True


# ---------- RUT que deben ser rechazados ----------

def test_rut_con_digito_incorrecto_es_invalido():
    assert validar_rut("12.345.678-9") is False


def test_texto_vacio_es_invalido():
    assert validar_rut("") is False


def test_rut_sin_guion_es_invalido():
    assert validar_rut("123456785") is False


def test_rut_con_letras_en_el_cuerpo_es_invalido():
    assert validar_rut("12.34A.678-5") is False
