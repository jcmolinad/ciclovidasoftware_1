"""Pruebas de calcular_envio() escritas ANTES que el código (TDD).

MISIÓN 2: ejecuta
    python -m pytest tests/test_envio.py -v
Todo sale en ROJO porque la función aún no está escrita.
Implementa calcular_envio() en tienda/validaciones.py hasta ver todo en VERDE.
Avancen de a una prueba: no intenten resolver todo de una vez.
"""
from tienda.validaciones import calcular_envio


def test_compra_grande_tiene_envio_gratis():
    assert calcular_envio(80000, "RM") == 0


def test_compra_de_exactamente_50000_tiene_envio_gratis():
    assert calcular_envio(50000, "Valparaíso") == 0


def test_compra_chica_en_rm_paga_3990():
    assert calcular_envio(20000, "RM") == 3990


def test_compra_de_49990_en_rm_paga_3990():
    assert calcular_envio(49990, "RM") == 3990


def test_compra_chica_en_region_paga_6990():
    assert calcular_envio(20000, "Biobío") == 6990


def test_region_en_minusculas_se_reconoce():
    assert calcular_envio(20000, "rm") == 3990
