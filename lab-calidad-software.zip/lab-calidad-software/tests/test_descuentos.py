"""Pruebas de descuento_por_cantidad().

MISIÓN 3 (cazadores de bugs): ejecuta
    python -m pytest tests/test_descuentos.py -v
Todas las pruebas pasan... pero la función TIENE defectos.
Lee el REQUISITO al inicio de tienda/descuentos.py y escribe abajo nuevas
pruebas que demuestren los defectos (deben salir en ROJO).
Después corrige el código hasta que todo quede en VERDE.

Pista: los errores suelen esconderse en los BORDES de un rango.
Para probar que algo lanza un error, usa:

    with pytest.raises(ValueError):
        descuento_por_cantidad(...)
"""
import pytest

from tienda.descuentos import descuento_por_cantidad


def test_pocas_unidades_no_tienen_descuento():
    assert descuento_por_cantidad(2) == 0


def test_cantidad_media_tiene_10_por_ciento():
    assert descuento_por_cantidad(7) == 10


def test_muchas_unidades_tienen_20_por_ciento():
    assert descuento_por_cantidad(15) == 20


# ---------- MISIÓN 3: escribe tus pruebas aquí ----------
