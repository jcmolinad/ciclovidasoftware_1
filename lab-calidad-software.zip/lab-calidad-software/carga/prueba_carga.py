"""Prueba de carga sencilla (como JMeter o k6, pero en 60 líneas).

Simula clientes comprando al mismo tiempo en la tienda durante el Cyber Day.

Con el servidor corriendo en otra terminal, ejecuta:
    python carga/prueba_carga.py --usuarios 5
    python carga/prueba_carga.py --usuarios 20
    python carga/prueba_carga.py --usuarios 100

CRITERIO DE ACEPTACIÓN (acordado con el cliente, estilo ATDD):
    El 95% de las peticiones responde en menos de 500 ms
    y no hay errores.
"""
import argparse
import threading
import time
import urllib.error
import urllib.request

URL = "http://localhost:8080/"
P95_MAXIMO_MS = 500


def usuario(peticiones, tiempos, errores, candado):
    for _ in range(peticiones):
        inicio = time.perf_counter()
        try:
            with urllib.request.urlopen(URL, timeout=5) as r:
                r.read()
            ok = True
        except (urllib.error.URLError, OSError):
            ok = False
        ms = (time.perf_counter() - inicio) * 1000
        with candado:
            (tiempos if ok else errores).append(ms)


def main():
    ap = argparse.ArgumentParser(description="Prueba de carga de la tienda")
    ap.add_argument("--usuarios", type=int, default=10, help="usuarios simultáneos")
    ap.add_argument("--peticiones", type=int, default=10, help="peticiones por usuario")
    a = ap.parse_args()

    tiempos, errores, candado = [], [], threading.Lock()
    hilos = [threading.Thread(target=usuario, args=(a.peticiones, tiempos, errores, candado))
             for _ in range(a.usuarios)]
    print(f"Lanzando {a.usuarios} usuarios x {a.peticiones} peticiones...")
    inicio = time.perf_counter()
    for h in hilos:
        h.start()
    for h in hilos:
        h.join()
    duracion = time.perf_counter() - inicio

    total = len(tiempos) + len(errores)
    tiempos.sort()
    p50 = tiempos[len(tiempos) // 2] if tiempos else 0
    p95 = tiempos[int(len(tiempos) * 0.95) - 1] if tiempos else 0
    tasa_error = 100 * len(errores) / total if total else 100

    print("-" * 46)
    print(f"Peticiones totales     : {total}")
    print(f"Peticiones por segundo : {total / duracion:.0f}")
    print(f"Tiempo mediano (p50)   : {p50:.0f} ms")
    print(f"Tiempo p95             : {p95:.0f} ms")
    print(f"Errores                : {len(errores)} ({tasa_error:.1f}%)")
    print("-" * 46)
    if total and tasa_error == 0 and p95 < P95_MAXIMO_MS:
        print("RESULTADO: CUMPLE el criterio de aceptación")
    else:
        print("RESULTADO: NO CUMPLE el criterio de aceptación")


if __name__ == "__main__":
    main()
