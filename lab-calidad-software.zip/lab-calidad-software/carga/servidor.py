"""Servidor web de prueba: la tienda online "TecnoMarket" en pleno Cyber Day.

Ejecutar en una terminal (y dejarlo corriendo):
    python carga/servidor.py

El servidor atiende como máximo CAPACIDAD peticiones al mismo tiempo,
y cada una tarda unos 50 ms (simula consultar una base de datos).
Si una petición espera más de 1 segundo por un lugar, responde 503
(Servicio no disponible), igual que un servidor saturado.
"""
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PUERTO = 8080
CAPACIDAD = 10            # peticiones simultáneas que el servidor puede procesar
TIEMPO_TRABAJO = 0.05     # segundos que tarda cada petición
ESPERA_MAXIMA = 1.0       # segundos de espera antes de rendirse (503)

cupos = threading.Semaphore(CAPACIDAD)


class Tienda(BaseHTTPRequestHandler):
    def do_GET(self):
        if not cupos.acquire(timeout=ESPERA_MAXIMA):
            self.send_response(503)
            self.end_headers()
            self.wfile.write(b"Servidor saturado")
            return
        try:
            time.sleep(TIEMPO_TRABAJO)
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"TecnoMarket OK")
        finally:
            cupos.release()

    def log_message(self, *args):
        pass  # silencia el log por cada petición


class Servidor(ThreadingHTTPServer):
    request_queue_size = 1024
    daemon_threads = True


if __name__ == "__main__":
    print(f"Tienda TecnoMarket escuchando en http://localhost:{PUERTO}  (Ctrl+C para detener)")
    print(f"Capacidad: {CAPACIDAD} peticiones simultáneas, {int(TIEMPO_TRABAJO*1000)} ms cada una")
    try:
        Servidor(("localhost", PUERTO), Tienda).serve_forever()
    except KeyboardInterrupt:
        print("\nServidor detenido")
