"""Descuentos por cantidad de la tienda online "TecnoMarket".

REQUISITO (acordado con el área comercial):
    - De 1 a 4 unidades del mismo producto   -> 0% de descuento
    - De 5 a 9 unidades                      -> 10% de descuento
    - 10 unidades o más                      -> 20% de descuento
    - Una cantidad de 0 o negativa no tiene sentido: debe lanzar ValueError.
"""


def descuento_por_cantidad(cantidad):
    """Devuelve el porcentaje de descuento (0, 10 o 20) según la cantidad comprada."""
    if cantidad <= 5:
        return 0
    elif cantidad < 10:
        return 10
    else:
        return 20
