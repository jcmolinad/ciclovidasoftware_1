"""Validaciones de la tienda online (ficticia) "TecnoMarket".

Este módulo se usa en el checkout: antes de emitir la boleta, el sistema
valida el RUT del cliente y calcula el costo de envío.
"""


def validar_rut(rut):
    """Devuelve True si `rut` es un RUT chileno válido (dígito verificador correcto).

    Acepta el RUT con o sin puntos, siempre con guión: "12.345.678-5" o "12345678-5".
    El dígito verificador puede ser un número o la letra K (mayúscula o minúscula).

    Cálculo del dígito verificador (algoritmo módulo 11):
      1. Se multiplican los dígitos del cuerpo, de derecha a izquierda,
         por la serie 2, 3, 4, 5, 6, 7, 2, 3, ...
      2. Se suman los productos.
      3. resto = 11 - (suma % 11)
      4. Si resto es 11, el dígito es "0". Si resto es 10, el dígito es "K".
         En otro caso, el dígito es el mismo número.
    """
    rut = rut.replace(".", "").upper()
    if "-" not in rut:
        return False
    cuerpo, dv = rut.split("-", 1)
    if not cuerpo.isdigit() or len(dv) != 1:
        return False

    suma = 0
    multiplicador = 2
    for digito in reversed(cuerpo):
        suma += int(digito) * multiplicador
        multiplicador = 2 if multiplicador == 7 else multiplicador + 1

    resto = 11 - (suma % 11)
    if resto == 11:
        esperado = "K"
    elif resto == 10:
        esperado = "0"
    else:
        esperado = str(resto)
    return dv == esperado


def calcular_envio(total, region):
    """Devuelve el costo de envío en pesos chilenos.

    Reglas acordadas con el área comercial:
      - Compras de $50.000 o más: envío gratis ($0), a cualquier región.
      - Compras menores a $50.000 en la Región Metropolitana ("RM"): $3.990.
      - Compras menores a $50.000 en cualquier otra región: $6.990.
      - La región puede venir escrita en mayúsculas o minúsculas.
    """
    # MISIÓN 2: las pruebas de esta función ya están escritas en
    # tests/test_envio.py. Escribe aquí el código para que pasen.
    raise NotImplementedError("Misión 2: implementa calcular_envio()")
