# Laboratorio: pruebas automáticas desde la terminal

**Ciclo de Vida del Software · Clase 2.2.1 · Escuela de Informática y Telecomunicaciones**

> **El foco de este laboratorio**
> Una prueba automática es una pregunta que el computador responde solo: *¿el sistema cumple lo que prometimos?*
> Hoy van a **ejecutar** pruebas, **leer** fallos, **escribir** pruebas antes del código y descubrir que **una prueba en verde no garantiza que el código esté bien**.
> No necesitan saber programar en profundidad: el código es corto y está comentado.

El repositorio simula el checkout de una **tienda online** ficticia, *TecnoMarket*: valida el RUT del cliente, calcula el costo de envío y aplica descuentos por cantidad. Además trae un servidor de prueba de la tienda para simular el **Cyber Day** con una prueba de carga.

```
lab-calidad-software/
├── tienda/
│   ├── validaciones.py   ← validar_rut(), calcular_envio()
│   └── descuentos.py     ← descuento_por_cantidad()
├── tests/
│   ├── test_rut.py       ← Misión 1
│   ├── test_envio.py     ← Misión 2
│   └── test_descuentos.py← Misión 3
├── carga/
│   ├── servidor.py       ← Misión 4: la tienda en Cyber Day
│   └── prueba_carga.py   ← Misión 4: generador de carga
└── .github/workflows/pruebas.yml  ← pipeline que corre las pruebas en cada push
```

---

## Misión 0 · Preparar el ambiente (5 min)

En la terminal de VS Code (**Terminal → New Terminal**):

```bash
git clone <URL-DEL-REPOSITORIO>
cd lab-calidad-software
code .
python -m pip install -r requirements.txt
python -m pytest --version
```

> **En Windows**, si `python` no funciona, prueben con `py` (por ejemplo, `py -m pytest`).
> Si `code .` no abre VS Code, ábranlo a mano con **File → Open Folder**.

✅ Listo cuando vean algo como `pytest 8.x.x`.

---

## Misión 1 · Leer un fallo (8 min)

**Concepto:** prueba unitaria y prueba de regresión.

```bash
python -m pytest tests/test_rut.py -v
```

Van a ver varias pruebas en verde (`PASSED`) y **tres en rojo** (`FAILED`).

1. Lean los mensajes de error: ¿qué pruebas fallaron?, ¿qué RUT usaron? ¿Qué tienen en común esos RUT?
2. Abran `tienda/validaciones.py`, lean cómo se calcula el dígito verificador (está explicado en el código) y busquen el defecto en `validar_rut()`.
3. Corrijan **el código, no las pruebas**, y vuelvan a ejecutar hasta ver todo en verde.

**Para responder:** tres pruebas fallaron, ¿cuántos defectos había? Si este validador estuviera en producción, ¿qué le pasaría a un cliente cuyo RUT termina en K?

---

## Misión 2 · TDD: de rojo a verde (10 min)

**Concepto:** Test-Driven Development. Las pruebas existen **antes** que el código.

```bash
python -m pytest tests/test_envio.py -v
```

Todo sale en rojo: la función `calcular_envio()` aún no está escrita, pero sus pruebas sí.

1. Lean las pruebas en `tests/test_envio.py`: ellas **son** la especificación.
2. Escriban el código de `calcular_envio()` en `tienda/validaciones.py`.
3. Ejecuten las pruebas después de cada cambio. Avancen de a una prueba en verde.

> **Pista:** basta con tres `if` y `region.upper()`.

**Para responder:** ¿por qué existen las pruebas con exactamente $50.000 y con $49.990? ¿Qué error típico detectan?

---

## Misión 3 · Cazadores de bugs (10 min)

**Concepto:** prueba exploratoria y valores límite. *Verde no significa correcto.*

```bash
python -m pytest tests/test_descuentos.py -v
```

Todo pasa. Sin embargo, `descuento_por_cantidad()` **tiene defectos**.

1. Lean el **REQUISITO** al inicio de `tienda/descuentos.py`.
2. Comparen el requisito con el código. ¿Qué casos no están cubiertos por las pruebas?
3. Escriban nuevas pruebas al final de `tests/test_descuentos.py` que **demuestren** cada defecto (deben salir en rojo).
4. Corrijan el código hasta que todo quede en verde.

> **Pista:** los errores se esconden en los **bordes**: prueben exactamente 5, exactamente 10 y cantidades que no deberían existir.

**Para responder:** ¿cuántos defectos encontraron? ¿Por qué las pruebas originales no los detectaban?

---

## Misión 4 · Prueba de carga (10 min)

**Concepto:** pruebas de carga y estrés con un criterio de aceptación medible (ATDD).

Se acerca el Cyber Day. **Criterio de aceptación acordado con el área comercial:** el 95% de las peticiones responde en menos de 500 ms y no hay errores.

Abran **dos terminales** en VS Code (botón `+` del panel de terminal).

Terminal 1, levanten la tienda y déjenla corriendo:
```bash
python carga/servidor.py
```

Terminal 2, aumenten la carga paso a paso:
```bash
python carga/prueba_carga.py --usuarios 5
python carga/prueba_carga.py --usuarios 20
python carga/prueba_carga.py --usuarios 50
python carga/prueba_carga.py --usuarios 100
python carga/prueba_carga.py --usuarios 300
```

Completen la tabla:

| Usuarios | Peticiones/s | p95 (ms) | Errores | ¿Cumple? |
|---:|---:|---:|---:|:---:|
| 5 | | | | |
| 20 | | | | |
| 50 | | | | |
| 100 | | | | |
| 300 | | | | |

**Para responder:**
- ¿Con cuántos usuarios deja de cumplir el criterio? Esa es la **capacidad** del sistema.
- ¿Qué pasa con 300 usuarios? Eso ya es una **prueba de estrés**.
- ¿Qué cambiarían para soportar 300 clientes simultáneos? (Miren la variable `CAPACIDAD` en `carga/servidor.py`, cámbienla y repitan la prueba).

Para detener el servidor: `Ctrl + C` en la terminal 1.

---

## Cierre · La puerta de calidad

Ejecuten **todas** las pruebas juntas:

```bash
python -m pytest -v
```

Si todo está en verde, su código pasaría la "puerta" del pipeline. El archivo `.github/workflows/pruebas.yml` hace exactamente esto en GitHub cada vez que alguien hace `push`: si una prueba falla, el cambio queda marcado en **rojo** y no debería llegar a producción.

| Misión | Lo que practicaron | Concepto de la clase |
|---|---|---|
| 1 | Leer un fallo y corregir el código | Prueba unitaria, regresión |
| 2 | Escribir código para pruebas que ya existían | TDD (rojo, verde, refactor) |
| 3 | Encontrar defectos que las pruebas no veían | Pruebas exploratorias, valores límite |
| 4 | Medir contra un criterio acordado | Carga, estrés, ATDD |
| Cierre | Ejecutar todo como una puerta | Pipeline de calidad (CI) |
